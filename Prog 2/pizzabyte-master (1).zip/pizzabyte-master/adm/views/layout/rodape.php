
    <footer>
        <p>Acesso em: <?=$_SESSION['inicio'] ?></p>
        <p>Backoffice</p>
        <p>Administração</p>
    </footer>
</body>
</html>