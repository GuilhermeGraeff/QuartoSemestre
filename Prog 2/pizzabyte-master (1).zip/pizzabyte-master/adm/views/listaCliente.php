<main>
    <h2><?=$titulo ?></h2>
    <hr>
    <br><br>
    <p>| <a href="clienteController.php?acao=cadastra">inserir novo</a> |</p>

    <?php
    if(count($lista) == 0){
        echo "<p>Nenhum cliente encontrado.</p>";
    }
    else{
        ?>
        <table>
        <tr>
            <th>Código</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Telefone</th>
            <th>Ações</th>
        </tr>  
        <?php      
        foreach ($lista as $cliente){
        ?>     
            <tr>
                <td><?=$cliente->getCodigo() ?></td>
                <td><?=$cliente->getNome() ?></td>
                <td><?=$cliente->getEmail() ?></td>
                <td><?=$cliente->getTelefone() ?></td>
                <td>
                <a href="clienteController.php?acao=altera&cod=<?=$cliente->getCodigo() ?>">alterar</a> 
                | 
                <a href="clienteController.php?acao=exclui&cod=<?=$cliente->getCodigo() ?>" 
                onclick="return confirm('Tem certeza de que deseja excluir este cliente?')">excluir</td>
            </tr>
        <?php
        }
    }
    ?>
    </table>
</main>




