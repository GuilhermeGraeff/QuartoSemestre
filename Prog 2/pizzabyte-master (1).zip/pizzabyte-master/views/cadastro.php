<h2>Cadastro</h2>
<hr>
<div class="erro_cadastro">
        <?php
        if (isset($erros) && count($erros) != 0) {
            echo "<ul>";
            foreach ($erros as $e)
                echo "<li>$e</li>";
            echo "</ul>";
        }

        $nome = isset($_POST['field_nome']) ? $_POST['field_nome'] : "";
        $email = isset($_POST['field_email']) ? $_POST['field_email'] : "";
        $tel = isset($_POST['field_tel']) ? $_POST['field_tel'] : "";
        $data = isset($_POST['field_dn']) ? $_POST['field_dn'] : "";
        $end = isset($_POST['field_endereco']) ? $_POST['field_endereco'] : "";
        $bairro = isset($_POST['field_bairro']) ? $_POST['field_bairro'] : "";
        $cc = isset($_POST['field_comoConheceu']) ? $_POST['field_comoConheceu'] : "";
        $ppi = isset($_POST['field_promo1']) ? 1 : 0;
        $ppa = isset($_POST['field_promo2']) ? 1 : 0;     
        $obs = isset($_POST['field_obs']) ? $_POST['field_obs'] : "";
        
        ?>
    </div>
    
<form method="POST" action="?acao=cadastro">
<div>
            <label for="id_nome">Nome completo: </label>
            <input type="text" name="field_nome" size="50" maxlength="50" id="id_nome" autofocus autocomplete="off"  value="<?=$nome ?>" >
        </div>
        <div>
            <label for="id_email">E-mail: </label>
            <input type="email" name="field_email" size="50" maxlength="50" placeholder="Informe o e-mail utilizado no cadastro" id="id_email" value="<?=$email ?>">
        </div>
        <div>
            <label for="id_tel">Telefone: </label>
            <input type="tel" name="field_tel" id="id_tel" value="<?=$tel ?>">
        </div>
        <div>
            <label for="id_dn">Data de nascimento: </label>
            <input type="date" name="field_dn" id="id_dn" value="<?=$data ?>">
        </div>
        <div>
            <label for="id_senha1">Senha: </label>
            <input type="password" name="field_senha1" id="id_senha1">
        </div>
        <div>
            <label for="id_senha2">Confirme a senha: </label>
            <input type="password" name="field_senha2" id="id_senha2">
        </div>
        <div>
            <label for="id_endereco">Endereço: </label>
            <input type="text" name="field_endereco" size="50" maxlength="50" id="id_endereco" placeholder="Rua, número, complemento"  value="<?=$end ?>">
        </div>
        <div>
            <label for="id_bairro">Bairro:</label>
            <select id="id_bairro" name="field_bairro">
                <option>Selecione</option>
                <option <?= ($bairro == "Centro") ? "selected" : "" ?>>Centro</option>
                <option <?= ($bairro == "Maria Goretti") ? "selected" : "" ?>>Maria Goretti</option>
                <option <?= ($bairro == "Santa Maria") ? "selected" : "" ?>>Santa Maria</option>
                <option <?= ($bairro == "Efapi") ? "selected" : "" ?>>Efapi</option>
                <option <?= ($bairro == "Engenho Braum") ? "selected" : "" ?>>Engenho Braum</option>
            </select>
        </div>
        <div>
            <fieldset>
                <legend>Como você conheceu nossa empresa?</legend>
                <label><input type="radio" name="field_comoConheceu" value="1" <?= ($cc == "1") ? "checked" : "" ?>>Loja física</label>
                <br>
                <label><input type="radio" name="field_comoConheceu" value="2" <?= ($cc == "2") ? "checked" : "" ?>>Redes sociais</label>
                <br>
                <label><input type="radio" name="field_comoConheceu" value="3" <?= ($cc == "3") ? "checked" : "" ?>>Publicidade</label>
                <br>
                <label><input type="radio" name="field_comoConheceu" value="4" <?= ($cc == "4") ? "checked" : "" ?>>Indicação de
                    amigos</label>
            </fieldset>
        </div>
        <div>
            <label><input type="checkbox" name="field_promo1" value="sim" <?= ($ppi == 1) ? "checked" : "" ?>>
                Quero receber promoções da Pizza Byte
            </label>
            <br>
            <label><input type="checkbox" name="field_promo2" value="sim" <?= ($ppa == 1) ? "checked" : "" ?>>
                Quero receber promoções das empresas parceiras
            </label>
        </div>
        <div>
            <label for="id_obs">Observações:</label><br>
            <textarea name="field_obs" rows="5" cols="50" placeholder="Informações adicionais" id="id_obs"><?=$obs ?></textarea>
        </div>

    <br>

    <br>
    <div>
        <input type="submit" value="Cadastrar" name="cadastrar">
        <input type="reset" value="Limpar campos">
    </div>
</form>