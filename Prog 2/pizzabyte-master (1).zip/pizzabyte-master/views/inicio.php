<h2>Início</h2>
<hr>
<div id="imgByte">
    <picture>
        <source media="(min-width: 700px)" srcset="assets/images/pizza.jpg" width="200px">
        <img src="assets/images/pizza_byte.jpg" id="byte" alt="Imagem de uma pizza pixelizada">
    </picture>
    <h3>Love at first byte!</h3>
</div>