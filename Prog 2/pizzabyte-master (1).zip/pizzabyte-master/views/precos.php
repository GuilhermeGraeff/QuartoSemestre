
    <h2>Preços</h2>
    <hr>
    <p>Conheça nossas opções:</p>
    <table>
        <tr>
            <th>Tamanho</th>
            <th>Número de sabores</th>
            <th>Preço</th>
        </tr>
        <tr>
            <td>Broto</td>
            <td>1</td>
            <td>25,00</td>
        </tr>               
        <tr>
            <td>Pequena</td>
            <td>2</td>
            <td>40,00</td>
        </tr> 
        <tr>
            <td>Média</td>
            <td>2</td>
            <td>45,00</td>
        </tr>   
        <tr>
            <td>Grande</td>
            <td>3</td>
            <td>55,00</td>
        </tr>    
        <tr>
            <td>Gigante</td>
            <td>4</td>
            <td>68,00</td>
        </tr>                                                 
    </table>

