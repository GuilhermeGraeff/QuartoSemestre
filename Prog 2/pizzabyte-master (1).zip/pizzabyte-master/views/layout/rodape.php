
    <aside>
        <h4>Promoção da semana</h4>
    </aside>

    <footer>
        <div id="chat">
            <div id="texto">Clique aqui para falar com os atendentes</div>
            <div id="botoes">
                <span id="minChat" class="btChat" onclick="minChat()">&or;</span>
                <span id="maxChat" class="btChat" onclick="maxChat()">&and;</span>
                <span id="closeChat" class="btChat" onclick="closeChat()">x</span>
            </div>
        </div>
        <p>Pizzaria Byte</p>
        <p>
            Peça pelo telefone (49)00000-0000
        </p>
        <ul>
            <li><a href="https://www.facebook.com/pizzabyte/"><img src="assets/images/facebook.png" alt="Facebook"></a>
            </li>
            <li><a href="https://www.twitter.com/pizzabyte/"><img src="assets/images/twitter.png" alt="Twitter"></a>
            </li>
        </ul>
    </footer>
</body>
<script src="assets/js/functions.js"></script>
</html>