<?php
    class Pizza{

        private $tamanho;
        private $sabores; // array(cod, nome)
        private $borda;

        public function getTamanho(){
            switch($this->tamanho){
                case 'b':
                    return "Broto";
                    break;
                case "p":
                    return "Pequena";
                    break;    
                case "m":
                    return "Média";
                    break; 
                case "g":
                    return "Grande";
                    break; 
                case "gg":
                    return "Gigante";
                    break;                                                                                  
            }
        }

        public function setTamanho($tamanho){
            $this->tamanho = $tamanho;
        }

        public function getSabores(){
            return $this->sabores;
        }

        public function setSabores($sabores){ 
            $this->sabores = $sabores;
        }

        public function getListaSabores(){ // formato textual 
            $str = "";
            foreach($this->sabores as $s)
                $str .=$s[1].", "; // separa por virgula e espaço
             
            return substr($str, 0, strlen($str)-2); // retira ultima virgula e espaço
        }        

        public function getBorda(){
            return $this->borda;
        }

        public function setBorda($borda){
            $this->borda = $borda;
        }  
        
        public function getPreco(){
            switch($this->tamanho){
                case 'b':
                    return 25;
                    break;
                case "p":
                    return 40;
                    break;    
                case "m":
                    return 45;
                    break; 
                case "g":
                    return 55;
                    break; 
                case "gg":
                    return 68;
                    break;                                                                                  
            }
        }
    }
?>